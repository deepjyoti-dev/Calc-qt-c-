#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QGridLayout>
#include <QVBoxLayout>

class Calculator : public QWidget
{
    Q_OBJECT

public:
    Calculator(QWidget *parent = nullptr);

private slots:
    void digitClicked();
    void operatorClicked();
    void equalClicked();
    void clearClicked();
    void decimalClicked();
    void functionClicked();
    void backspaceClicked();

private:
    QLineEdit *display;
    QTextEdit *history;
    QString pendingOperator;
    double pendingOperand = 0;
    bool waitingForOperand = true;

    void abortOperation();
    bool calculate(double rightOperand, const QString &operatorText);
};

#endif // CALCULATOR_H
